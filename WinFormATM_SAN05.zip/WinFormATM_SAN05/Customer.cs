﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;//added
using System.Data.SqlClient; //added

namespace WinFormATM_SAN05
{
    class Customer
    {
        public int CustomerPk { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public long PersonalID { get; private set; }
        public string Phone { get; private set; }
        public string Address { get; private set; }

        public DataTable selectCustomers()
        {
            DataAccessLayer dal = new DataAccessLayer();
            string query = "select * from Customers";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandText = query;
            return dal.selectData(sqlCommand);
        }
        public int selectCustomer(long personal_id)
        {
            string query = "select CustomerPk, FirstName, LastName, PersonalID, Phone, Address from Customers where PersonalID = @personal_id";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandText = query;
            sqlCommand.Parameters.AddWithValue("@personal_id", personal_id);
            DataAccessLayer dal = new DataAccessLayer();
            if (dal.connectionOpen())
            {
                SqlDataReader reader = dal.returnReader(sqlCommand);
                if (reader.HasRows)
                {
                    reader.Read();
                    this.CustomerPk = Convert.ToInt32(reader[0].ToString());
                    this.FirstName = reader[1].ToString();
                    this.LastName = reader[2].ToString();
                    this.PersonalID = Convert.ToInt64(reader[3].ToString());
                    this.Phone = reader[4].ToString();
                    this.Address = reader[5].ToString();
                    reader.Close();
                    dal.connectionClose();
                    return 1;
                }
                else
                {
                    dal.connectionClose();
                    return -1;

                }
            }
            else return -2;
        }

        public void resetCustomer()
        {
            this.CustomerPk = 0;
            this.FirstName = "";
            this.LastName = "";
            this.PersonalID = 0;
            this.Phone = "";
            this.Address = "";
        }

        public void setCustomer(string f_name, string l_name, long personal_id, string phone_no, string address)
        {
            this.CustomerPk = 0;
            this.FirstName = f_name;
            this.LastName = l_name;
            this.PersonalID = personal_id;
            this.Phone = phone_no;
            this.Address = address;
        }

        public int selectCustomerPK(long personal_id)
        {
            int result = -2;
            string query = "select CustomerPK from Customers where PersonalID = @personal_id";
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.CommandText = query;
            sqlCommand.Parameters.AddWithValue("@personal_id", personal_id);
            DataAccessLayer dal = new DataAccessLayer();
            if (dal.connectionOpen())
            {
                result = dal.selectValue(sqlCommand);
                dal.connectionClose();
            }
            return result;


        }
    }
}


    
