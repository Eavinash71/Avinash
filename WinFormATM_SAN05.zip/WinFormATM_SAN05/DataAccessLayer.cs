﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WinFormATM_SAN05
{
    class DataAccessLayer
    {
        SqlConnection sqlConnection =
           new SqlConnection(ConfigurationManager.ConnectionStrings["BankDatabaseConnectionString"].ConnectionString);

        public DataTable selectData(SqlCommand sqlCommand)
        {
            sqlCommand.Connection = sqlConnection;
            SqlDataAdapter sda = new SqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            return dt;

        }
        public SqlDataReader returnReader(SqlCommand sqlCommand)
        {
            sqlCommand.Connection = sqlConnection;
            return sqlCommand.ExecuteReader();

        }
        public int selectValue(SqlCommand sqlCommand)
        {
            sqlCommand.Connection = sqlConnection;
            try
            {
                int result = (int)sqlCommand.ExecuteScalar();

                return result;

            }
            catch


            {
                return -1;
            }

        }

        public int executeQuery(SqlCommand sqlCommand)
        {
            sqlCommand.Connection = sqlConnection;
            return sqlCommand.ExecuteNonQuery();
        }
        public bool connectionOpen()
        {
            try
            {
                sqlConnection.Open();
                return true;
            }
            catch
            { return false; }
        }
        public bool connectionClose()
        {
            try
            {
                sqlConnection.Close();
                return true;
            }
            catch { return false; }
        }
    }
}