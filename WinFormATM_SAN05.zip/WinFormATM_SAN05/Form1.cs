﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormATM_SAN05
{
    public partial class Form1 : Form
    {
        Customer customer;
        
        public Form1()
        {
            InitializeComponent();
            customer = new Customer();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bankDatabaseDataSet.Customers' table. You can move, or remove it, as needed.
            //this.customersTableAdapter.Fill(this.bankDatabaseDataSet.Customers);
            dataGridView1.DataSource = customer.selectCustomers();
            dataGridView1.Refresh();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSelectCustomer_Click(object sender, EventArgs e)
        {
            long personal_id = Convert.ToInt64(txtBoxPersonalID.Text);
            int result = customer.selectCustomer(personal_id);
            if (result == 1)
            {
                labInfo.Text = "PK = " + customer.CustomerPk + "\n" + "first name = " + customer.FirstName + "\n" + 
                    
                    "last name = " + customer.LastName + "\n" + "peronal ID = " + customer.PersonalID + "\n" + "phone = " + customer.Phone + "\n" + "address = " + customer.Address;
            }
            else if (result == -1)
                labInfo.Text = "the customer with ID = " + personal_id.ToString() + " not found";
            else labInfo.Text = "problem with the connection";
            customer.resetCustomer();

        }

        private void btnCustomerPk_Click(object sender, EventArgs e)
        {
            long personal_id = Convert.ToInt64(txtBoxPersonalID.Text);
            int result = customer.selectCustomerPK(personal_id);
            labInfo.Text = result.ToString();

        }
    }
}
